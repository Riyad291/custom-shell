#!/bin/sh
set -eu

test_dir=$(mktemp -d /tmp/csc332-shell.XXXXXX)
trap 'rm -rf "$test_dir"' EXIT

printf 'INFO started\nERROR failed\n' > "$test_dir/sample.log"

printf 'one\ntwo\n' > "$test_dir/first.txt"
printf 'one\nTwo\n' > "$test_dir/second.txt"
printf '\000A' > "$test_dir/first.bin"
printf '\000B' > "$test_dir/second.bin"

./custom_shell > "$test_dir/output" 2>&1 <<INPUT
help
loganalyzer -f $test_dir/sample.log
timedexec -t 1 -- sleep 3
timedexec -t 3 -- true
loganalyzer -l ERROR -f $test_dir/sample.log
processgroup help
filediffadvanced -h
filediffadvanced $test_dir/first.txt $test_dir/first.txt
filediffadvanced -v $test_dir/first.txt $test_dir/second.txt
filediffadvanced --verbose $test_dir/first.bin $test_dir/second.bin
filediffadvanced -q $test_dir/first.txt $test_dir/second.txt
filediffadvanced $test_dir/missing.txt $test_dir/first.txt
loganalyzer -f $test_dir/sample.log
unknown_command
exit
INPUT

output="$test_dir/output"
grep -Fq 'loganalyzer -h' "$output"
grep -Fq 'timedexec -h' "$output"
grep -Eq '^Lines: +2$' "$output"
grep -Fq 'timedexec returned 124' "$output"
grep -Fq 'timedexec: process exited with status 0' "$output"
grep -Eq '^Matched: +1 line' "$output"
grep -Fq 'unknown command: unknown_command' "$output"
grep -Fq 'Usage: processgroup' "$output"
grep -Fq 'Usage: filediffadvanced' "$output"
grep -Fq 'Files are identical' "$output"
grep -Fq 'Difference at line 2, column 1' "$output"
grep -Fq 'Difference at byte offset 1: 0x41 vs 0x42' "$output"
test "$(grep -c 'Comparing:' "$output")" -eq 3
test "$(grep -c 'filediffadvanced returned 1' "$output")" -eq 3
grep -Fq 'filediffadvanced returned 2' "$output"
test "$(grep -c 'Lines:     2' "$output")" -eq 3
echo "Custom Shell tests passed."
