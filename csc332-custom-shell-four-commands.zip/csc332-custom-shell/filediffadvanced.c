#define _POSIX_C_SOURCE 200809L
#ifdef __APPLE__
#define _DARWIN_C_SOURCE
#endif
#include <errno.h>
#include <fcntl.h>
#include <getopt.h>
#include <inttypes.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/resource.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>

#include "filediffadvanced.h"

#define DEFAULT_LIMIT 20

typedef struct {
    int fd;
    const unsigned char *data;
    size_t size;
    bool mapped;
    const char *name;
} mapped_file;

static void usage(FILE *out, const char *program) {
    fprintf(out,
        "Usage: %s [OPTIONS] FILE1 FILE2\n"
        "Compare two files and report text or binary differences.\n\n"
        "Options:\n"
        "  -v, --verbose   Show every differing byte position\n"
        "  -q, --quiet     Print only errors; use exit status to check result\n"
        "  -h, --help      Show this help message\n\n"
        "Exit status: 0 = identical, 1 = different, 2 = error\n", program);
}

static int open_mapped(mapped_file *file, const char *path) {
    struct stat st;
    file->fd = -1;
    file->data = NULL;
    file->size = 0;
    file->mapped = false;
    file->name = path;

    file->fd = open(path, O_RDONLY);
    if (file->fd == -1) {
        fprintf(stderr, "filediffadvanced: cannot open '%s': %s\n", path, strerror(errno));
        return -1;
    }
    if (fstat(file->fd, &st) == -1) {
        fprintf(stderr, "filediffadvanced: cannot get information for '%s': %s\n", path, strerror(errno));
        close(file->fd);
        file->fd = -1;
        return -1;
    }
    if (!S_ISREG(st.st_mode)) {
        fprintf(stderr, "filediffadvanced: '%s' is not a regular file\n", path);
        close(file->fd);
        file->fd = -1;
        return -1;
    }
    if (st.st_size < 0 || (uintmax_t)st.st_size > SIZE_MAX) {
        fprintf(stderr, "filediffadvanced: '%s' is too large to map\n", path);
        close(file->fd);
        file->fd = -1;
        return -1;
    }
    file->size = (size_t)st.st_size;
    if (file->size > 0) {
        void *address = mmap(NULL, file->size, PROT_READ, MAP_PRIVATE, file->fd, 0);
        if (address == MAP_FAILED) {
            fprintf(stderr, "filediffadvanced: mmap failed for '%s': %s\n", path, strerror(errno));
            close(file->fd);
            file->fd = -1;
            return -1;
        }
        file->data = (const unsigned char *)address;
        file->mapped = true;
    }
    return 0;
}

static void close_mapped(mapped_file *file) {
    if (file->mapped)
        munmap((void *)file->data, file->size);
    if (file->fd != -1)
        close(file->fd);
}

static bool contains_nul(const mapped_file *file) {
    return file->size > 0 && memchr(file->data, '\0', file->size) != NULL;
}

static void printable_byte(unsigned char c, char *buffer, size_t length) {
    if (c == '\n') snprintf(buffer, length, "\\n");
    else if (c == '\r') snprintf(buffer, length, "\\r");
    else if (c == '\t') snprintf(buffer, length, "\\t");
    else if (c >= 32 && c <= 126) snprintf(buffer, length, "'%c'", c);
    else snprintf(buffer, length, "0x%02X", c);
}

static void text_position(const unsigned char *data, size_t offset,
                          size_t *line, size_t *column) {
    *line = 1;
    *column = 1;
    for (size_t i = 0; i < offset; i++) {
        if (data[i] == '\n') {
            (*line)++;
            *column = 1;
        } else {
            (*column)++;
        }
    }
}

int cmd_filediffadvanced(int argc, char **argv) {
    bool verbose = false, quiet = false;
    static const struct option long_options[] = {
        {"verbose", no_argument, NULL, 'v'},
        {"quiet", no_argument, NULL, 'q'},
        {"help", no_argument, NULL, 'h'},
        {NULL, 0, NULL, 0}
    };

    /* The shell can call this command repeatedly in the same process. */
#ifdef __APPLE__
    optreset = 1;
    optind = 1;
#else
    optind = 0;
#endif
    int option;
    while ((option = getopt_long(argc, argv, "vqh", long_options, NULL)) != -1) {
        switch (option) {
            case 'v': verbose = true; break;
            case 'q': quiet = true; break;
            case 'h': usage(stdout, argv[0]); return 0;
            default: usage(stderr, argv[0]); return 2;
        }
    }
    if (argc - optind != 2) {
        usage(stderr, argv[0]);
        return 2;
    }

    mapped_file first, second;
    if (open_mapped(&first, argv[optind]) == -1)
        return 2;
    if (open_mapped(&second, argv[optind + 1]) == -1) {
        close_mapped(&first);
        return 2;
    }

    struct timespec start, finish;
    struct rusage usage_before, usage_after;
    clock_gettime(CLOCK_MONOTONIC, &start);
    getrusage(RUSAGE_SELF, &usage_before);

    bool binary = contains_nul(&first) || contains_nul(&second);
    size_t common = first.size < second.size ? first.size : second.size;
    size_t differences = 0;
    size_t shown = 0;
    size_t limit = verbose ? (size_t)-1 : DEFAULT_LIMIT;

    if (!quiet) {
        printf("Comparing: %s (%zu bytes) and %s (%zu bytes)\n",
               first.name, first.size, second.name, second.size);
        printf("Detected format: %s\n", binary ? "binary" : "text");
    }

    for (size_t i = 0; i < common; i++) {
        if (first.data[i] != second.data[i]) {
            differences++;
            if (!quiet && shown < limit) {
                if (binary) {
                    printf("Difference at byte offset %zu: 0x%02X vs 0x%02X\n",
                           i, first.data[i], second.data[i]);
                } else {
                    size_t line, column;
                    char a[16], b[16];
                    text_position(first.data, i, &line, &column);
                    printable_byte(first.data[i], a, sizeof(a));
                    printable_byte(second.data[i], b, sizeof(b));
                    printf("Difference at line %zu, column %zu (byte %zu): %s vs %s\n",
                           line, column, i, a, b);
                }
                shown++;
            }
        }
    }

    if (first.size != second.size) {
        differences += first.size > second.size ? first.size - second.size : second.size - first.size;
        if (!quiet && shown < limit) {
            printf("File sizes differ: %zu bytes vs %zu bytes\n", first.size, second.size);
            shown++;
        }
    }

    clock_gettime(CLOCK_MONOTONIC, &finish);
    getrusage(RUSAGE_SELF, &usage_after);
    double elapsed = (double)(finish.tv_sec - start.tv_sec) +
                     (double)(finish.tv_nsec - start.tv_nsec) / 1000000000.0;

    if (!quiet) {
        if (!verbose && shown >= DEFAULT_LIMIT && differences > shown)
            printf("Additional differences were found but not displayed. Use -v to show all.\n");
        if (differences == 0)
            printf("Result: Files are identical.\n");
        else
            printf("Result: Files are different (%zu differing byte/size positions).\n", differences);
        printf("Comparison time: %.6f seconds\n", elapsed);
        printf("User CPU time: %ld.%06ld seconds\n",
               (long)(usage_after.ru_utime.tv_sec - usage_before.ru_utime.tv_sec),
               (long)(usage_after.ru_utime.tv_usec - usage_before.ru_utime.tv_usec));
        printf("System CPU time: %ld.%06ld seconds\n",
               (long)(usage_after.ru_stime.tv_sec - usage_before.ru_stime.tv_sec),
               (long)(usage_after.ru_stime.tv_usec - usage_before.ru_stime.tv_usec));
    }

    close_mapped(&first);
    close_mapped(&second);
    return differences == 0 ? 0 : 1;
}

#ifdef STANDALONE
int main(int argc, char **argv) {
    return cmd_filediffadvanced(argc, argv);
}
#endif
