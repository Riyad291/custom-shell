#ifndef FILEDIFFADVANCED_H
#define FILEDIFFADVANCED_H

int cmd_filediffadvanced(int argc, char **argv);

#endif
