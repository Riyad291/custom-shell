#define _POSIX_C_SOURCE 200809L

#include <errno.h>
#include <getopt.h>
#include <sys/wait.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "filediffadvanced.h"
#include "loganalyzer.h"
#include "timedexec.h"
#include "processgroup.h"

static const struct {
    const char *name;
    int (*run)(int argc, char **argv);
} commands[] = {
    {"loganalyzer", cmd_loganalyzer},
    {"timedexec", cmd_timedexec},
    {"processgroup", processgroup_main},
    {"filediffadvanced", cmd_filediffadvanced}
};

static void handle_interrupt(int signal_number)
{
    (void)signal_number;
}

int main(void)
{
    char *line = NULL;
    size_t capacity = 0;
    int interactive = isatty(STDIN_FILENO);
    int status = 0;

    struct sigaction action = {0};
    action.sa_handler = handle_interrupt;
    sigemptyset(&action.sa_mask);
    if (sigaction(SIGINT, &action, NULL) == -1) {
        perror("custom_shell: sigaction");
        return 1;
    }

    while (1) {
        /* Collect finished background jobs between shell commands. */
        while (waitpid(-1, NULL, WNOHANG) > 0) {
        }

        if (interactive) {
            printf("Custom Shell> ");
            fflush(stdout);
        }

        errno = 0;
        if (getline(&line, &capacity, stdin) == -1) {
            if (errno == EINTR) {
                clearerr(stdin);
                if (interactive)
                    putchar('\n');
                continue;
            }
            if (!feof(stdin)) {
                perror("custom_shell: getline");
                status = 1;
            }
            break;
        }

        char *argv[128];
        int argc = 0;
        char *word = strtok(line, " \t\r\n");

        while (word != NULL && argc < 127) {
            argv[argc++] = word;
            word = strtok(NULL, " \t\r\n");
        }
        argv[argc] = NULL;

        if (word != NULL) {
            fprintf(stderr, "Custom Shell: too many arguments\n");
            continue;
        }
        if (argc == 0)
            continue;
        if (strcmp(argv[0], "exit") == 0)
            break;

        size_t i = 0;
        size_t count = sizeof commands / sizeof commands[0];

        if (strcmp(argv[0], "help") == 0) {
            puts("Available commands:");
            for (i = 0; i < count; i++)
                printf("  %s -h\n", commands[i].name);
            puts("  help\n  exit");
            continue;
        }

        for (i = 0; i < count; i++) {
            if (strcmp(argv[0], commands[i].name) == 0) {
                int saved_opterr = opterr;
                int result = commands[i].run(argc, argv);
                opterr = saved_opterr;
                if (result != 0)
                    fprintf(stderr, "%s returned %d\n", argv[0], result);
                break;
            }
        }
        if (i == count)
            fprintf(stderr, "Custom Shell: unknown command: %s\n", argv[0]);
    }

    free(line);
    return status;
}
